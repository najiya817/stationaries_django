from django.db import models
from django.contrib.auth.models import User

# Create your models here.


#model for profile
class UserProfile(models.Model):
    profile_pic=models.ImageField(upload_to="profile_pictures")
    age=models.IntegerField()
    options=(
        ('Male','Male'),
        ('Female','Female')
    )
    gender=models.CharField(max_length=100,choices=options,default="Female")
    phone=models.IntegerField()
    user=models.OneToOneField(User,on_delete=models.CASCADE,related_name="p_user")

