from typing import Any
from django.forms.models import BaseModelForm
from django.http import HttpRequest, HttpResponse
from django.shortcuts import render,redirect
from .forms import *
from django.views.generic import CreateView,FormView,View
from django.contrib.auth.models import User
from django.urls import reverse_lazy
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

# Create your views here.


#view of registration
class RegView(CreateView):
    template_name="reg.html"
    form_class=RegForm
    model=User
    success_url=reverse_lazy('log')
    def post(self,request,*args,**kwargs):
        form_data=RegForm(data=request.POST)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"registration succesfull")
            return redirect("log")
        else:
            messages.error(request,"registration failed")
            return render(request,"reg.html",{"form":form_data})


#view for login
class LogView(FormView):
    template_name="log.html"
    form_class=LogForm
    def post(self, request, *args, **kwargs):
        form_data=LogForm(data=request.POST)
        if form_data.is_valid():
            un=form_data.cleaned_data.get("username")            
            ps=form_data.cleaned_data.get("password")
            user=authenticate(request,username=un,password=ps)
            if user:
                if user.is_superuser:
                    login(request,user)
                    return redirect("ah")
                login(request,user)
                return redirect("home")
            else:
                return redirect("log")
        else:
            return redirect(request,"log.html",{"form":form_data})
        

#view for logout
class LogOutView(View):
    def get(self,request):
        logout(request)
        return redirect("log")