from django.shortcuts import render,redirect,get_object_or_404
from django.views.generic import CreateView,TemplateView,UpdateView,DeleteView,View
from .models import Products,CartItem
from .forms import AddProductForm
from django.urls import reverse_lazy
from django.contrib import messages
from django.utils.decorators import method_decorator

# Create your views here.

def signin_required(fn):
    def wrapper(request,*args,**kwargs):
        if request.user.is_authenticated:
            return fn(request,*args,**kwargs)
        else:
            return redirect("log")
    return wrapper


#View of Mainhome page
@method_decorator(signin_required,name='dispatch')
class Homeview(CreateView):
    template_name="mainhome.html"
    model=Products
    form_class=AddProductForm
    def get(self,request,*args,**kwargs):
        data=Products.objects.all()
        return render(request,"mainhome.html",{"data":data})
    

#Add To Cart
def add_to_cart(request,id):
    user = request.user
    product = Products.objects.get(id=id)
    # when user is authenticated
    if user.is_authenticated:
        try:
            cart_item = CartItem.objects.get(product=product,user=user)
            cart_item.quantity += 1
            cart_item.save()
        except CartItem.DoesNotExist:
            cart_item = CartItem.objects.create(
                product=product,
                user=user,
                quantity = 1,
            )
            cart_item.save()
            
        return redirect('home')
    

#View Cart
@method_decorator(signin_required,name='dispatch')
class ViewCart(TemplateView):
    template_name="addtocart.html"
    def get_context_data(self, **kwargs):
        context=super().get_context_data(**kwargs)
        context['data']=CartItem.objects.filter(user=self.request.user)
        return context



class DeleteCart(View):
    def get(self,request,*args,**kwargs):
        pid=kwargs.get("id")
        pr=CartItem.objects.get(id=pid)
        pr.delete()
        return redirect('cv')
