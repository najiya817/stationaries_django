from django import forms
from .models import Products,CartItem

#form to add product
class AddProductForm(forms.ModelForm):
    class Meta:
        model=Products
        fields=["name","price","details","image"]
        widget={
                "name":forms.TextInput(attrs={"class":"form-control"}),
                "price":forms.IntegerField(),
                "details":forms.Textarea(attrs={"class":"form-control"}),
                "image":forms.FileInput()
        }

#add product to cart
class AddCart(forms.ModelForm):
    class Meta:
        model=CartItem
        fields=["quantity"]
