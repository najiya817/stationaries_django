from django.urls import path
from .views import *

urlpatterns = [
    path('h',Homeview.as_view(),name="home"),
    path('ac/<int:id>',add_to_cart,name="ac"),
    path('cv',ViewCart.as_view(),name="cv"),
    path('delc/<int:id>',DeleteCart.as_view(),name='delc'),

    ]