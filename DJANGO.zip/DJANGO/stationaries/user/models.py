from django.db import models
from django.contrib.auth.models import User

# Create your models here.

#model for products
class Products(models.Model):
    name=models.CharField(max_length=100)
    price=models.IntegerField()
    details=models.CharField(max_length=400)
    image=models.ImageField(upload_to="product_pic")
    user=models.ForeignKey(User,on_delete=models.CASCADE,related_name="pro")
    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url
    
    
#products that added to cart
class CartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)