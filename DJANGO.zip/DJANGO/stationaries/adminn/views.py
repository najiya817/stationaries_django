from django.shortcuts import render,redirect
from django.views.generic import TemplateView,CreateView,DeleteView,UpdateView
from user.forms import AddProductForm
from user.models import Products
from django.urls import reverse_lazy
from django.contrib import messages
from django.utils.decorators import method_decorator

# Create your views here.

def signin_required(fn):
    def wrapper(request,*args,**kwargs):
        if request.user.is_authenticated:
            return fn(request,*args,**kwargs)
        else:
            return redirect("log")
    return wrapper


@method_decorator(signin_required,name='dispatch')
class AdminHome(TemplateView):
    template_name="adminhome.html"


#Add Product  
@method_decorator(signin_required,name='dispatch')
class AddProduct(CreateView):
    template_name="addproducts.html"
    form_class=AddProductForm
    model=Products
    success_url=reverse_lazy("ah")
    def form_valid(self,form):
        form.instance.user=self.request.user
        messages.success(self.request,"product added")
        self.object=form.save()
        return super().form_valid(form)
    def get_context_data(self,**kwargs):
        context=super().get_context_data(**kwargs)
        context["data"]=Products.objects.all()
        return context


#Page To Edit Or Delete 
@method_decorator(signin_required,name='dispatch')
class EditView(TemplateView):
    template_name="edit.html"
    model=Products
    form_class=AddProductForm
    def get(self,request,*args,**kwargs):
        data=Products.objects.all()
        return render(request,"edit.html",{"data":data})
    

#Update Product Details
@method_decorator(signin_required,name='dispatch')
class Edit(UpdateView):
    model=Products
    template_name="update.html"
    form_class=AddProductForm
    success_url=reverse_lazy("ah")
    pk_url_kwarg="pk"
    def form_valid(self,form):
        messages.success(self.request,"Product Updated succesfully")
        self.object=form.save()
        return super().form_valid(form)  


#Delete Product
@method_decorator(signin_required,name='dispatch')
class Deletep(DeleteView):
    model=Products
    template_name='delete.html'
    success_url=reverse_lazy("ah")

