from django.urls import path
from .views import *

urlpatterns = [
    
    path('add',AddProduct.as_view(),name="add"),
    path('mpv',EditView.as_view(),name="mpv"),
    path('up/<int:pk>',Edit.as_view(),name="up"),
    path('del/<int:pk>',Deletep.as_view(),name="del"),
    path('ah',AdminHome.as_view(),name="ah"),

]